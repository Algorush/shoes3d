import React, { useRef, useState, useEffect, forwardRef } from 'react';
import { OrbitControls, PerspectiveCamera } from '@react-three/drei';
import { useConfigurator } from './context/context';
import { isMobile } from 'orientation-check';
import * as THREE from 'three';  

export const RotatingCamera = forwardRef((props, modelRef) => {
    const { set } = useConfigurator()

const shoeGroup = modelRef.current?.shoeGroup.current || null;
const cameraRef = useRef();
const controlsRef = useRef();


  useEffect(() => {
    if (props.active) {  
   
      cameraRef.current.lookAt(0, 5, 0)
      set({ camera: cameraRef.current });
    }
  }, [props.active]);

  return (
    <>
      <PerspectiveCamera
        ref={cameraRef}
        fov={isMobile?50:30}
        position={isMobile ? [30, 30, 60] : [16.47, 30.416, 59.774]}
        rotation={[1.181, 0.091, -0.244]} 
      />
      <OrbitControls
        zoomSpeed={1.2}  // Установите скорость зуммирования
        enabled={true}   // Разрешаем управление на мобильных устройствах
        panSpeed={0.5}   // Настройка скорости панорамирования
        ref={controlsRef}
        camera={cameraRef.current}
        target={[0, 8, 0]}
        enableZoom={true}  // Включить зуммирование
        enableRotate={true}  // Включить вращение
        enablePan={false}  // Панорамирование можно оставить отключенным
        touches={{
          ONE: THREE.TOUCH.ROTATE,  // Вращение одним пальцем
          TWO: THREE.TOUCH.DOLLY_PAN,  // Зуммирование двумя пальцами
        }}
        enableDamping
        dampingFactor={0.1}
      />
    </>
  );
});
