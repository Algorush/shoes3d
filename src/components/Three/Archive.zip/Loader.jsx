import React from 'react';
import { useSnapshot } from 'valtio';
import { state } from './store';

const Loader = () => {
  const snap = useSnapshot(state.materials);  
  return (
    <div style={{ 
      position: 'absolute', 
      top: '50%', 
      left: '50%', 
      transform: 'translate(-50%, -50%)', 
      color: 'white',
      zIndex: 1000,
      background: 'rgba(0, 0, 0, 0.7)',
      padding: '20px',
      borderRadius: '10px',
      fontFamily: 'Din-Medium'
    }}>
      <h2>Loading 3D, please wait...</h2>
    </div>
  );
};

export default Loader;
