import React from "react";

export const PleaseWait=()=>{
return(
    <>
    <div><h2>Please wait.</h2></div>
</>
) 
}